﻿using System.Reflection;

[assembly: AssemblyTitle("hOOt Full Text Indexer")]
[assembly: AssemblyDescription("hOOt Full Text Indexer")]

[assembly: AssemblyProduct("RaptorDB Document Store")]


