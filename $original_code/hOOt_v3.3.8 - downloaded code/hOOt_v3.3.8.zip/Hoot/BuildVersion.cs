using System.Reflection;
// build number = 315
// build version = 3.3.8

[assembly: AssemblyVersion("3.0.0.0")]
[assembly: AssemblyFileVersion("3.3.8.315")]