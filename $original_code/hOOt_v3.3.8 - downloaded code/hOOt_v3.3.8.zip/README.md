hOOt
====

Smallest full text search engine (lucene replacement) built from scratch using inverted WAH bitmap index, highly compact storage, operating in database and document modes

see the article here : [http://www.codeproject.com/Articles/224722/hOOt-full-text-search-engine] (http://www.codeproject.com/Articles/224722/hOOt-full-text-search-engine)
